document.addEventListener("DOMContentLoaded", () => {

  let puntos = 0;
  const marcador = document.getElementById("puntosA");
  const boton = document.getElementById("sumarA");

  boton.addEventListener("click", () => {
    puntos++;
    marcador.textContent = puntos;
  });

});

document.addEventListener("DOMContentLoaded", () => {

  // ===== MARCADOR =====
  let puntosA = 0;
  let puntosB = 0;

  // Elementos del DOM
  const puntosAEl = document.getElementById("puntosA");
  const puntosBEl = document.getElementById("puntosB");
  const mensajePartido = document.getElementById("mensajePartido");

  const btnA = document.getElementById("sumarA");
  const btnB = document.getElementById("sumarB");
  const btnReset = document.getElementById("resetMarcador");

  const equipoA = document.querySelector(".equipo-a");
  const equipoB = document.querySelector(".equipo-b");

  // Botón +1 Sevilla
  btnA.addEventListener("click", () => {
    puntosA++;
    actualizarMarcador();
  });

  // Botón +1 Betis
  btnB.addEventListener("click", () => {
    puntosB++;
    actualizarMarcador();
  });

  // Reiniciar marcador
  btnReset.addEventListener("click", () => {
    puntosA = 0;
    puntosB = 0;
    actualizarMarcador();
    mensajePartido.textContent = "Marcador reiniciado";
  });

  // Actualiza puntos, mensaje y equipo ganador
  function actualizarMarcador() {
    puntosAEl.textContent = puntosA;
    puntosBEl.textContent = puntosB;

    // Quitamos estado ganador
    equipoA.classList.remove("ganando");
    equipoB.classList.remove("ganando");

    if (puntosA > puntosB) {
      mensajePartido.textContent = "Va ganando el Sevilla FC";
      equipoA.classList.add("ganando");
    } else if (puntosB > puntosA) {
      mensajePartido.textContent = "Va ganando el Real Betis";
      equipoB.classList.add("ganando");
    } else {
      mensajePartido.textContent = "El partido va empatado";
    }
  }

});
